<?php
		include "db.php";
        mysqli_query($db2,"TRUNCATE `reports`");
        $db = null;
        $db2 = null;
?>