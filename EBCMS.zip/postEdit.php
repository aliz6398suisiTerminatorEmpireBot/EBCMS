<?php

    session_start();
	$signin = false;
	
	// بررسی درخواست خروج از سایت
	if( isset( $_GET[ 'signout' ] ) ) {
		unset( $_SESSION[ 'username' ] );
	}
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
		include "db.php";
		$id = mysqli_real_escape_string($db2,$_POST["username"]);
		// جستجوی کاربران با نام کاربری وارد شده
		$stmt = $db->prepare( "SELECT * FROM posts where title = ?" );
		$stmt->bindValue( 1, $id );
		$stmt->execute();
		$user = $stmt->fetch( PDO::FETCH_OBJ );
            $thenum = $user->title;
            $newid2 = $_POST["newid"];
            $newpass2 = $_POST["newpass"];
            $newid2 = mysqli_real_escape_string($db2,$newid2);
		    $newpass2 = mysqli_real_escape_string($db2,$newpass2);
            mysqli_query($db2,"UPDATE posts SET title='$newid2',des='$newpass2' WHERE title='$thenum'");
        $db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
	<!-- اگر کاربر قبلا در سایت وارد نشده باشد -->
		<form method="POST">
            <input type="text" name="username"placeholder="POST TiTLE"><br>
            <input type="text" name="newid"placeholder="NEW POST TiTLE"><br><textarea name="newpass"placeholder="NEW POST DESCRiPTiON"></textarea><br>
			<input type="submit" value="ویرایش"style="background:#FFA000;color:#FFFFFF;"><br>
		</form>