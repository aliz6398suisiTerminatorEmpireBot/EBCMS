<?php
	$errors = array();
	$signup = false;
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
 
		// بررسی صحت اطلاعات وارد شده

		
		// بررسی عدم وجود خطا در مراحل قبلی
		if( count( $errors ) == 0 ) {
			include "db.php";
			//pn ,mail, title, takhalof, unblock
			// ثبت کاربر در پایگاه داده
			$title = $_POST["title"];
			$title = mysqli_real_escape_string($db2,$title);
			$des = $_POST["des"];
			$des = mysqli_real_escape_string($db2,$des);
			$publisher = $_POST["publisher"];
			$publisher = mysqli_real_escape_string($db2,$publisher);
			$stmt = $db->prepare( "INSERT INTO posts ( title, des, publisher) VALUES ( ?, ?, ? )" );
			$stmt->bindValue( 1, $title );
			$stmt->bindValue( 2, $des );
			$stmt->bindValue( 3, $publisher );
			$stmt->execute();
			
			$signup = true;
		}
		$db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
		<!-- نمایش فرم ثبت نام -->
		<form method="POST">
			<input type="text" name="title"placeholder="TiTLE"><br>
			<textarea type="des" name="des"placeholder="DESRiCPTiON"></textarea><br>
            <input type="text" name="publisher"placeholder="PUBLiSHER"><br>
		    <input type="submit" value="انتشار"style="background:#00A000;color:#FFFFFF;"><br>
		    <input type="reset">
		</form>
