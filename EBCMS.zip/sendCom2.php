<?php
    include "db.php";
    $posid = mysqli_real_escape_string($db2,$_POST["postid"]);
    $xx1 = mysqli_real_escape_string($db2,$_POST["userid"]);
    $xx2 = mysqli_real_escape_string($db2,$_POST["comtxt"]);
    $stmt = $db->prepare( "INSERT INTO comment2 ( ctext,csender,post ) VALUES ( ?, ?, ? )" );
	$stmt->bindValue( 1, $xx2 );
	$stmt->bindValue( 2, $xx1 );
	$stmt->bindValue( 3, $posid );
	$stmt->execute();
	$db = null;
	$db2 = null;
?>