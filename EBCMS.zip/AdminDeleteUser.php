<?php

    session_start();
	$signin = false;
	
	// بررسی درخواست خروج از سایت
	if( isset( $_GET[ 'signout' ] ) ) {
		unset( $_SESSION[ 'username' ] );
	}
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
		include "db.php";
 
		// جستجوی کاربران با نام کاربری وارد شده
		$stmt = $db->prepare( "SELECT * FROM users where id = ?" );
		$id = $_POST["username"];
		$id = mysqli_real_escape_string($db2,$id);
		$stmt->bindValue( 1, $id);
		$stmt->execute();
		$user = $stmt->fetch( PDO::FETCH_OBJ );
		
		// بررسی گذرواژه‌ی وارد شده با گذرواژه‌ی موجود در پایگاه داده

        $thenum = $user->number;
        mysqli_query($db2,"DELETE FROM users WHERE number='$thenum'");
        $db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
		<form method="POST">
            <input type="text" name="username"placeholder="iD">
			<input type="submit" value="حذف"style="background:#FF0000;color:#FFFFFF;"><br>
		</form>
