<textarea style='width:100%;background:linear-gradient(#ffd000,#4080ff);color:#FF0000;'rows='12'disabled>Array
(
    [id] => ADMiN
    [0] => ADMiN
    [number] => 0
    [1] => 0
    [mail] => aliz6398suisi@gmail.com
    [2] => aliz6398suisi@gmail.com
    [title] => ADMiN
    [3] => ADMiN
)</textarea>
<?php
include "db.php";

echo "<br>";
$result = $db->query( "SELECT * FROM users" );
while( $user = $result->fetch() ) {
    echo "<textarea style='width:100%;background:linear-gradient(#ffd000,#4080ff);color:#FF0000;'rows='25'disabled>";
    print_r($user);
    echo "</textarea>";
}
$db = null;
$db2 = null;
?>