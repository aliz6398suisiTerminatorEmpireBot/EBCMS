<?php

    session_start();
	$signin = false;
	
	// بررسی درخواست خروج از سایت
	if( isset( $_REQUEST[ 'signout' ] ) ) {
		unset( $_SESSION[ 'username' ] );
	}
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' || $_SERVER[ 'REQUEST_METHOD' ] == 'GET') {
		include "db.php";
		$tit = mysqli_real_escape_string($db2,$_REQUEST["username"]);
		$result = $db->query( "SELECT * FROM posts WHERE publisher='$tit'" );
		while( $user = $result->fetch() ) {
            echo "<fieldset class='comas'>تاریخ<fieldset class='comdt'>".$user["createdtime"]."</fieldset>عنوان";
            echo "<a href='getPost.php?username=".$user["title"]."'><fieldset class='comid'>";
            // CREATE TABLE `cms`.`posts` ( `title` TEXT NULL DEFAULT NULL , `des` LONGTEXT NULL DEFAULT NULL , `publisher` TEXT NULL DEFAULT NULL , `id` BIGINT NULL DEFAULT NULL , `createdtime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ) ENGINE = MyISAM;
            echo $user["title"]."</fieldset></a></fieldset>";
        }
		$db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
		.comas{
    background-color:#ffd000;
    color:#ff0000;
    border-radius:25px;
    border:2px solid #4080ff;
}
.comtxt{
    background-color:#4080ff;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comdt{
    background-color:#ff8000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comid{
    background-color:#00a000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comres{
    background-color:#ff0000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff8000;/*blue,red,gren,oran,mag*/
}
	</style>
		<form method="POST">
            <input type="text" name="username"placeholder="USER iD"><br>
			<input type="submit" value="مشاهده"style="background:#FFA000;color:#FFFFFF;"><br>
		</form>