<button>
    <a href="delrep.php">
        حذف همه گزارش ها
    </a>
</button>
<?php
include "db.php";

echo "<br>";
$result = $db->query( "SELECT * FROM reports" );
while( $user = $result->fetch() ) {
    echo "<textarea style='width:100%;background:linear-gradient(#ffd000,#4080ff);color:#FF0000;'rows='7'disabled>";
    print_r($user["des"]);
    echo "</textarea>";
}
$db = null;
$db2 = null;
?>