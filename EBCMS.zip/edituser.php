<?php

    session_start();
	$signin = false;
	
	// بررسی درخواست خروج از سایت
	if( isset( $_GET[ 'signout' ] ) ) {
		unset( $_SESSION[ 'username' ] );
	}
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
		include "db.php";
		$id = $_POST["username"];
		$id = mysqli_real_escape_string($db2,$id);
		// جستجوی کاربران با نام کاربری وارد شده
		$stmt = $db->prepare( "SELECT * FROM users where id = ?" );
		$stmt->bindValue( 1, $id );
		$stmt->execute();
		$user = $stmt->fetch( PDO::FETCH_OBJ );
		
		// بررسی گذرواژه‌ی وارد شده با گذرواژه‌ی موجود در پایگاه داده
		$password = "aliz6398suisiTerminatorEmpireBot".$_POST["password"]."aliz6398suisiTerminatorEmpireBot";
		$password = mysqli_real_escape_string($db2,$password);
        if( $user && password_verify( $password, $user->password ) ) {
//        if($user && $_POST['password']==$user->password){
            $thenum = $user->number;
            $newid2 = $_POST["newid"];
            $newpass2 = password_hash( "aliz6398suisiTerminatorEmpireBot".$_POST["newpass"]."aliz6398suisiTerminatorEmpireBot", PASSWORD_BCRYPT );
		    $newid2 = mysqli_real_escape_string($db2,$newid2);
		    $ppnn = $_POST["newtel"];
		    $mail = $_POST["newmail"];
		    $mail = mysqli_real_escape_string($db2,$mail);
		    $ppnn = mysqli_real_escape_string($db2,$ppnn);
		    $newpass2 = mysqli_real_escape_string($db2,$newpass2);
            mysqli_query($db2,"UPDATE users SET id='$newid2',password='$newpass2',mail='$mail',pn='$ppnn' WHERE number='$thenum'");
			// UPDATE USER
		}
		$db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
		<form method="POST">
            <input type="text" name="username"placeholder="iD"><br><input type="password" name="password"placeholder="PASSWORD"><br>
            <input type="text" name="newid"placeholder="NEW iD"><br><input type="password" name="newpass"placeholder="NEW PASSWORD"><br>
            <input type="gmail" name="newmail"placeholder="NEW GMAIL"><br><input type="tel" name="newtel"placeholder="NEW PHONE NUMBER"><br>
			<input type="submit" value="ویرایش"style="background:#FFA000;color:#FFFFFF;"><br>
		</form>