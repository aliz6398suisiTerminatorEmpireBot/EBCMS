<?php

    session_start();
	$signin = false;
	
	// بررسی درخواست خروج از سایت
	if( isset( $_GET[ 'signout' ] ) ) {
		unset( $_SESSION[ 'username' ] );
	}
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
		include "db.php";
		$id = $_POST["username"];
		$id = mysqli_real_escape_string($db2,$id);
		// جستجوی کاربران با نام کاربری وارد شده
		$stmt = $db->prepare( "SELECT * FROM users where id = ?" );
		$stmt->bindValue( 1, $id);
		$stmt->execute();
		$user = $stmt->fetch( PDO::FETCH_OBJ );
		
		// بررسی گذرواژه‌ی وارد شده با گذرواژه‌ی موجود در پایگاه داده
		$pass = mysqli_real_escape_string($db2,"aliz6398suisiTerminatorEmpireBot".$_POST["password"]."aliz6398suisiTerminatorEmpireBot");
        if( $user && password_verify( $pass, $user->password ) ) {
            if($user->title=="اکانت تعطیل"){
                die('<script>while(true){alert("این اکانت تعطیل است")}</script>');
            }
//        if($user && $_POST['password']==$user->password){
			$signin = true;
			$_SESSION['username'] = $user->id;
		}
		$db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
	<!-- اگر کاربر قبلا در سایت وارد نشده باشد -->
	<?php if( ! isset( $_SESSION[ 'username' ] ) ) : ?>
		<form method="POST">
            <input type="text" name="username"placeholder="iD"><br><input type="password" name="password"placeholder="PASSWORD"><br>
			<input type="submit" value="ورود"style="background:#00A000;color:#FFFFFF;"><br>
		</form>
	<?php else: ?>
		<!-- نمایش نام کاربر اگر در سایت وارد شده باشد -->
		<?php echo $_SESSION[ 'username' ]; ?>
		<hr>
		<!-- لینک به صفحه‌ی خروج از سایت -->
		<a href="?signout">خروج از سایت</a>
	<?php endif; ?>
</body>
</html>