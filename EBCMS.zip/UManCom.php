<table><tr>
    <td style='border:1px solid #000000'>فرستنده</td>
    <td style='border:1px solid #000000'>متن کامنت</td>
    <td style='border:1px solid #000000'>عنوان پست</td>
    <td style='border:1px solid #000000'>iD</td>
    <td style='border:1px solid #000000'>حذف</td>
    <td style='border:1px solid #000000'>ویرایش</td>
</tr>
<?php
// DELETE , EDIT , YES , NO
include "db.php";

echo "<br>";
$result = $db->query( "SELECT * FROM comment WHERE status='تایید شده'" );
while( $user = $result->fetch() ) {
    ?><tr><?php
    echo "<td style='border:1px solid #000000'>".$user["csender"]."</td>";
    echo "</td><td style='border:1px solid #000000'>".$user["ctext"]."</td>";
    ?></td><td style='border:1px solid #000000'>
    <a href='getPost.php?username=<?php
    echo $user["post"];
?>'><?php
    echo $user["post"];
?></a></td></td>
    <td style="border:1px solid #000000"><?php
    echo $user["id"];
    ?></td></a><td style="border:1px solid #000000">
        <form action="edcom.php"method="POST">
            <input name="forer"value="no"style="display:none">
            <input name="id"value="<?php echo $user["id"]; ?>"style="display:none">
            <input type="submit"value="حذف"style="background-color:#FF0000;color:#FFFFFF;">
    </form>
        <td style="border:1px solid #000000">
        <form action="edcom.php"method="POST">
            <input name="forer"value="edit"style="display:none">
            <input name="id"value="<?php echo $user["id"]; ?>"style="display:none">
            <textarea name="txt"rows="7"><?php echo $user["ctext"] ?></textarea><br>
            <input name="sender"value="<?php echo $user["csender"] ?>"><br>
            <input type="submit"value="ویرایش"style="background-color:#FF8000;color:#FFFFFF;">
    </form>
    </td>
    </tr><?php
}
$db = null;
$db2 = null;
?>
</table>