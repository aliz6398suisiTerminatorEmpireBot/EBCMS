<?php
include "db.php";

echo "<br>";
$result = $db->query( "SELECT * FROM posts" );
while( $user = $result->fetch() ) {
    ?>
    <textarea style='width:100%;background:linear-gradient(#ffd000,#4080ff);color:#FF0000;'rows='10'disabled>
    <?php
    print_r($user);
    echo "</textarea>";
}
$db = null;
$db2 = null;
?>