<?php

    session_start();
	$signin = false;
	
	// بررسی درخواست خروج از سایت
	if( isset( $_GET[ 'signout' ] ) ) {
		unset( $_SESSION[ 'username' ] );
	}
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
		include "db.php";
		$id = mysqli_real_escape_string($db2,$_POST["username"]);
		// جستجوی کاربران با نام کاربری وارد شده
		$stmt = $db->prepare( "SELECT * FROM users where id = ?" );
		$stmt->bindValue( 1, $id );
		$stmt->execute();
		$user = $stmt->fetch( PDO::FETCH_OBJ );
            $thenum = $user->number;
            $newid2 = $_POST["newid"];
            $newpass2 = password_hash( "aliz6398suisiTerminatorEmpireBot".$_POST["newpass"]."aliz6398suisiTerminatorEmpireBot", PASSWORD_BCRYPT );
            $newid2 = mysqli_real_escape_string($db2,$newid2);
            $til = mysqli_real_escape_string($db2,$_POST["tit"]);
		    $newpass2 = mysqli_real_escape_string($db2,$newpass2);
		    $newtel = $_POST["newtel"];
            $newmail = $_POST["newmail"];
            $newtel = mysqli_real_escape_string($db2,$newtel);
		    $newmail = mysqli_real_escape_string($db2,$newmail);
            mysqli_query($db2,"UPDATE users SET id='$newid2',password='$newpass2',pn='$newtel',mail='$newmail',title='$til' WHERE number='$thenum'");
        $db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
		<form method="POST">
            <input type="text" name="username"placeholder="iD"><br>
            <input type="text" name="newid"placeholder="NEW iD"><br><input type="password" name="newpass"placeholder="NEW PASSWORD"><br>
            <input type="email" name="newmail"placeholder="NEW GMAIL"><br><input type="tel" name="newtel"placeholder="NEW PHONE NUMBER"><br>
            <select name="tit">
                <option>
                    اکانت کاربر
                </option>
                <option>
                    اکانت ادمین
                </option>
                <option>
                    اکانت تعطیل
                </option>
            </select>
			<input type="submit" value="ویرایش"style="background:#FFA000;color:#FFFFFF;"><br>
		</form>
