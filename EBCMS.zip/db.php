<?php 
$dsn = 'mysql:dbname=cms;host=localhost';
$username = 'root';
$password = '';
try {
    $db = new PDO( $dsn, $username, $password );
    $db2 = mysqli_connect("localhost","root","","cms");
	$db->exec( "SET CHARACTER SET utf8" );
} catch( PDOException $e ) {
	die( 'رخداد خطا در هنگام ارتباط با پایگاه داده:<br>' . $e );
}
?>