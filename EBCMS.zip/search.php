<h1 id="red"></h1>
<?php
	$errors = array();
	$signup = false;
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
 
		// بررسی صحت اطلاعات وارد شده

		
		// بررسی عدم وجود خطا در مراحل قبلی
		if( count( $errors ) == 0 ) {
			include "db.php";
			//pn ,mail, title, takhalof, unblock
			$txt = $_POST[ 'txt' ];
			$txt = mysqli_real_escape_string($db2,$txt);
			echo "نتیجه جستجو Search Result <hr>";
			$res = $db->query("SELECT * FROM posts WHERE title LIKE '%$txt%'");
			$searchres = 0;
			while( $user = $res->fetch() ) {
                echo "<textarea style='width:100%;background:linear-gradient(#ffd000,#4080ff);color:#FF0000;'rows='10'disabled>";
                print_r($user);
                echo "</textarea>";
                $searchres += 1;
            }
			echo "<script>document.getElementById('red').innerHTML='$searchres'</script>";
			if($searchres==0){
			    echo "<h1>چیزی پیدا نشد</h1>";
			}
			$signup = true;
		}
		$db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
	<?php if( $signup == false ) : ?>
		
		<?php
			// نمایش پیام‌های خطا در صورت وجود
			foreach( $errors as $error ) {
				echo "<p>{$error}</p>";
			}
			endif;
		?>
		
		<!-- نمایش فرم ثبت نام -->
		<form method="POST">
			<input type="search" name="txt"placeholder="TEXT TO SEARCH"><br>
		    <input type="submit" value="جستجو"style="background:#00A000;color:#FFFFFF;"><br>
		    <input type="reset">
		</form>