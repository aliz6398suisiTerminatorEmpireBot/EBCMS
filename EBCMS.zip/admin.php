<!-- کامنت و پست و پاسخ و گزارش و  کاربر-->
<h1>
    کاربر
</h1>
<ul>
<li><a href="adminDeleteUser.php">
    حذف کاربر
</a></li>
<li><a href="signup.php">
    ساخت کاربر
</a></li>
<li><a href="edituserAdmin.php">
    ویرایش کاربر
</a></li>
<li><a href="printAllUser.php">
    نمایش کاربران
</a></li>
</ul>
<h1>
    <a href="printReport.php">
        گزارش ها
    </a>
</h1>
<h1>
    پست
</h1>
<ul>
<li><a href="postDelete.php">
    حذف پست
</a></li>
<li><a href="publishPost.php">
    ساخت پست
</a></li>
<li><a href="postEdit.php">
    ویرایش پست
</a></li>
<li><a href="printAllPost.php">
    نمایش پست ها
</a></li>
<li><a href="ManCom.php">
    مدیریت کامنت ها
</a></li>
<li><a href="ManCom2.php">
    مدیریت پاسخ ها
</a></li>
</ul>
<h1>امار</h1>
<ul>
<li>
    کل کاربران : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM users");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    مدیران : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM users WHERE title='اکانت ادمین'");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    کاربران معمولی : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM users WHERE title='اکانت کاربر'");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    اکانت های تعطیل شده : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM users WHERE title='اکانت تعطیل'");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    کل پست ها : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM posts");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    گزارش های ارسال شده : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM reports");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    کل کامنت ها : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM comment");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    کل پاسخ ها : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM comment2");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    کل کامنت های تایید شده : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM comment WHERE status='تایید شده'");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    کل پاسخ های تایید شده : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM comment2 WHERE status='تایید شده'");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    کل کامنت های تایید نشده : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM comment WHERE status='تایید نشده'");
        echo mysqli_num_rows($x);
    ?>
</li>
<li>
    کل پاسخ های تایید نشده : <?php
        include "db.php";
        $x = mysqli_query($db2,"SELECT * FROM comment2 WHERE status='تایید نشده'");
        echo mysqli_num_rows($x);
    ?>
</li>
</ul>
<h1>صد پست اخیر<br><ul>
    <?php
        include "db.php";
        $result = $db->query( "SELECT * FROM posts" );
while( $user = $result->fetch() ) {
    echo "<li>";
    ?><a href='getPost.php?username=<?php
    echo $user["title"];
?>'><?php
    echo $user["title"];
?></a><?php
    echo "</li>";
}
    ?>
</ul></h1>