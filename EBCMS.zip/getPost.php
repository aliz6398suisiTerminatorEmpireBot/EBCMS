	<meta charset='UTF-8'>
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
.comas{
    background-color:#ffd000;
    color:#ff0000;
    border-radius:25px;
    border:2px solid #4080ff;
}
.comtxt{
    background-color:#4080ff;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comdt{
    background-color:#ff8000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comid{
    background-color:#00a000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comres{
    background-color:#ff0000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff8000;/*blue,red,gren,oran,mag*/
}
		
	</style>

<?php

    session_start();
	$signin = false;
	
	// بررسی درخواست خروج از سایت
	if( isset( $_GET[ 'signout' ] ) ) {
		unset( $_SESSION[ 'username' ] );
	}
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' || $_SERVER[ 'REQUEST_METHOD' ] == 'GET' ) {
	    include "db.php";
	    $id = $_REQUEST["username"];
		$id = mysqli_real_escape_string($db2,$id);
        $result = $db->query( "SELECT * FROM posts WHERE title='$id'" );
        while( $user = $result->fetch() ) {
            echo '<h1 style="font-size:96px"id="a">';
            echo $user["title"];
            
            ?></h1><hr><h2 style='font-size:64px'>منتشر کننده : <a href="getUserPost.php?username=<?php
            echo $user["publisher"].'">'.$user["publisher"]."</a>";
            echo "</h2><h3 style='line-height:32px;font-size:27px;'>";
            echo $user["des"];
            echo "</h2><h3 style='line-height:32px;font-size:20px;'>منتشر شده در : ";
            echo $user["createdtime"];
            echo "</h3><h1 style='font-size:45px;'>کامنت ها</h1><fieldset>";
            $ut = $user["title"];
            $result2 = $db->query( "SELECT * FROM comment WHERE status='تایید شده' AND post='$ut'" );
            while( $user2 = $result2->fetch() ) {
                echo "<fieldset class='comas'style=''>فرستنده";
                echo "<fieldset class='comid'>";
                echo $user2["csender"];
                echo "</fieldset>تاریخ<fieldset class='comdt'>";
                echo $user2["createdtime"];
                echo "</fieldset>متن<fieldset class='comtxt'>";
                echo $user2["ctext"];
                echo "</fieldset>پاسخ ها<fieldset class='comres'>";
                $rr2 = $user2["id"];
                $result3 = $db->query( "SELECT * FROM comment2 WHERE status='تایید شده' AND post='$rr2'" );
                while( $user3 = $result3->fetch() ) {
                    echo "<fieldset class='comas'style=''>فرستنده";
                    echo "<fieldset class='comid'>";
                    echo $user3["csender"];
                    echo "</fieldset>تاریخ<fieldset class='comdt'>";
                    echo $user3["createdtime"];
                    echo "</fieldset>متن<fieldset class='comtxt'>";
                    echo $user3["ctext"];
                    echo "</fieldset></fieldset>";
                }
                ?>
                <form method='POST'action='sendCom2.php'>
		    <input value='<?php 
		        echo $user2['id'];
		    ?>'name='postid'style="display:none;"><BR>
		    <input placeholder="USER iD"name="userid"><BR>
		    <textarea placeholder="COMMENT TEXT"name="comtxt"rows="7"></textarea><BR>
		    <input type="submit"style="background-color:#00A000;color:#FFFFFF;"value="ارسال پاسخ"><BR>
		    <input type="reset">
		</form>
                <?php
                echo "</fieldset>";
                echo "</fieldset>";
            }
            ?></fieldset>
            <?php
            break;
        }
        
		$db = null;
        $db2 = null;
	}
?>
	<meta charset='UTF-8'>
		<form method='POST'>
            <input type='text' name='username'placeholder='POST TiTLE'><br>
			<input type='submit' value='ورود'style='background:#00A000;color:#FFFFFF;'><BR>
		</form>
		<form method='POST'action='sendCom.php'>
		    <input value='<?php 
		    if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' || $_SERVER[ 'REQUEST_METHOD' ] == 'GET' ) {
		        echo $user['title'];
		    }
		    ?>'name='postid'style="display:none;"><BR>
		    <input placeholder="USER iD"name="userid"><BR>
		    <textarea placeholder="COMMENT TEXT"name="comtxt"rows="7"></textarea><BR>
		    <input type="submit"style="background-color:#00A000;color:#FFFFFF;"value="send COMMENT"><BR>
		    <input type="reset">
		</form>