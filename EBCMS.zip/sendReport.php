<?php
	$errors = array();
	$signup = false;
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
 
		// بررسی صحت اطلاعات وارد شده
		// بررسی عدم وجود خطا در مراحل قبلی
			include "db.php";
			$des = mysqli_real_escape_string($db2,$_POST["des"]);
			$stmt = $db->prepare( "INSERT INTO reports ( des ) VALUES ( ? )" );
			$stmt->bindValue( 1, $des );
			$stmt->execute();
		$db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
	<?php if( $signup == false ) : ?>
		
		<?php
			// نمایش پیام‌های خطا در صورت وجود
			foreach( $errors as $error ) {
				echo "<p>{$error}</p>";
			}
		?>
		
		<!-- نمایش فرم ثبت نام -->
		<form method="POST">
			<textarea type="text" name="des"placeholder="توضیحات گزاش"rows="7"cols="12"></textarea><br>
<input type="submit" value="ارسال گزارش"style="background:#FFA000;color:#FFFFFF;"><br>
		    <input type="reset">
		</form>
	<?php else: ?>
		<!-- نمایش پیام ورود به سایت -->
		اطلاعات بدون مشکل ثبت شد
		<hr>
		<a href="signin.php">ورود به سایت</a>
	<?php endif; ?>