<?php
    if($_POST["forer"]=="no"){
        include "db.php";
        $id = mysqli_real_escape_string($db2,$_POST["id"]);
        mysqli_query($db2,"DELETE FROM comment2 WHERE id='$id'");
    	$db = null;
	    $db2 = null;
    }
    if($_POST["forer"]=="yes"){
        include "db.php";
        $id = mysqli_real_escape_string($db2,$_POST["id"]);
        mysqli_query($db2,"UPDATE comment2 SET status='تایید شده' WHERE id='$id'");
    	$db = null;
	    $db2 = null;
    }
    if($_POST["forer"]=="edit"){
        // sender,txt
        include "db.php";
        $id = mysqli_real_escape_string($db2,$_POST["id"]);
        $sender = mysqli_real_escape_string($db2,$_POST["sender"]);
        $txt = mysqli_real_escape_string($db2,$_POST["txt"]);
        mysqli_query($db2,"UPDATE comment2 SET csender='$sender',ctext='$txt' WHERE id='$id'");
    	$db = null;
	    $db2 = null;
    }
    if($_POST["forer"]=="noo"){
        // sender,txt
        include "db.php";
        $id = mysqli_real_escape_string($db2,$_POST["id"]);
        mysqli_query($db2,"UPDATE comment2 SET status='تایید نشده' WHERE id='$id'");
    	$db = null;
	    $db2 = null;
    }
?>