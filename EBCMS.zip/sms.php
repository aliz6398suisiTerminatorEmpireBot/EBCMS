<?php

    session_start();
	$signin = false;
	
	// بررسی درخواست خروج از سایت
	if( isset( $_GET[ 'signout' ] ) ) {
		unset( $_SESSION[ 'username' ] );
	}
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
		include "db.php";
		$id = $_POST["username"];
		$id = mysqli_real_escape_string($db2,$id);
		// جستجوی کاربران با نام کاربری وارد شده
		$stmt = $db->prepare( "SELECT * FROM users where id = ?" );
		$stmt->bindValue( 1, $id);
		$stmt->execute();
		$user = $stmt->fetch( PDO::FETCH_OBJ );
		
		// بررسی گذرواژه‌ی وارد شده با گذرواژه‌ی موجود در پایگاه داده
		$pass = mysqli_real_escape_string($db2,"aliz6398suisiTerminatorEmpireBot".$_POST["password"]."aliz6398suisiTerminatorEmpireBot");
        if( $user && password_verify( $pass, $user->password ) ) {
            if($user->title=="اکانت تعطیل"){
                die('<script>while(true){alert("این اکانت تعطیل است")}</script>');
            }
//        if($user && $_POST['password']==$user->password){
			$signin = true;
			$ui = $user->id;
			$_SESSION['username'] = $user->id;
			$result2 = $db->query( "SELECT * FROM sms WHERE geter='$ui' OR sender='$ui'" );
			?>
			<form action='sendsms.php'method="POST">
			    <input name="s"value="<?php echo $ui; ?>"style="display:none">
			    <input name="g"placeholder="گیرنده"><BR>
			    <textarea rows="7"name="t"placeholder='متن پیام'></textarea><BR>
			    <input style="background-color:#00a000;color:#FFFFFF;"type="submit"value="ارسال"><BR>
			</form>
			<?php
            while( $user2 = $result2->fetch() ) {
                if($user2["sender"]==$ui && $user2["geter"]==$ui){
                    echo "<fieldset class='comas2'style=''><fieldset class='comid2'>";
                    echo $user2["geter"];
                    echo "</fieldset>تاریخ<fieldset class='comdt2'>";
                    echo $user2["date"];
                    echo "</fieldset>متن<fieldset class='comtxt2'>";
                    echo $user2["text"];
                    echo "</fieldset></fieldset>";
                }else if($user2["sender"]==$ui){
                    echo "<fieldset class='comas'style=''>";
                    echo "<fieldset class='comid'>";
                    if($user2["sender"] == $ui){
                        echo $user2["geter"];
                    }
                    if($user2["geter"] == $ui){
                        echo $user2["sender"];
                    }
                    echo "</fieldset>تاریخ<fieldset class='comdt'>";
                    echo $user2["date"];
                    echo "</fieldset>متن<fieldset class='comtxt'>";
                    echo $user2["text"];
                    echo "</fieldset></fieldset>";
                }else if($user2["geter"] == $ui){
                    echo "<fieldset class='comas1'style=''>";
                    echo "<fieldset class='comid1'>";
                    if($user2["sender"] == $ui){
                        echo $user2["geter"];
                    }
                    if($user2["geter"] == $ui){
                        echo $user2["sender"];
                    }
                    echo "</fieldset>تاریخ<fieldset class='comdt1'>";
                    echo $user2["date"];
                    echo "</fieldset>متن<fieldset class='comtxt1'>";
                    echo $user2["text"];
                    echo "</fieldset></fieldset>";
                }
            }
		}
		$db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
.comas{
    background-color:#ffd000;
    color:#ff0000;
    border-radius:25px;
    border:2px solid #4080ff;
}
.comtxt{
    background-color:#4080ff;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comdt{
    background-color:#ff8000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comid{
    background-color:#00a000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #ff0000;
}
.comas1{
    background-color:#4080FF;
    color:#FFD000;
    border-radius:25px;
    border:2px solid #FFD000;
}
.comtxt1{
    background-color:#FF00FF;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #FFD000;
}
.comdt1{
    background-color:#FF0000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #FFD000;
}
.comid1{
    background-color:#FF8000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #FFD000;
}
.comas2{
    background-color:#FF0000;
    color:#FFFFFF;
    border-radius:25px;
    border:2px solid #4080ff;
}
.comtxt2{
    background-color:#4080ff;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #FFD000;
}
.comdt2{
    background-color:#00A000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #FFD000;
}
.comid2{
    background-color:#FF8000;
    color:#ffffff;
    border-radius:25px;
    border:2px solid #FFD000;
}
	</style>
		<form method="POST">
            <input type="text" name="username"placeholder="iD"><br><input type="password" name="password"placeholder="PASSWORD"><br>
			<input type="submit" value="ورود"style="background:#00A000;color:#FFFFFF;"><br>
		</form>