<?php
	$errors = array();
	$signup = false;
	
	if( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
 
		// بررسی صحت اطلاعات وارد شده

		
		// بررسی عدم وجود خطا در مراحل قبلی
		if( count( $errors ) == 0 ) {
			include "db.php";
			//pn ,mail, title, takhalof, unblock
			// ثبت کاربر در پایگاه داده
			$id = $_POST["username"];
			$id = mysqli_real_escape_string($db2,$id);
			$pn = $_POST["pn"];
			$pn = mysqli_real_escape_string($db2,$pn);
			$mail = $_POST["mail"];
			$mail = mysqli_real_escape_string($db2,$mail);
			$password = password_hash( "aliz6398suisiTerminatorEmpireBot".$_POST[ 'password' ]."aliz6398suisiTerminatorEmpireBot", PASSWORD_BCRYPT ); 
			$password = mysqli_real_escape_string($db2,$password);
			$stmt = $db->prepare( "INSERT INTO users ( id, password, pn, mail, title ) VALUES ( ?, ?, ?, ?, ? )" );
			$stmt->bindValue( 1, $id );
			$stmt->bindValue( 2, $password );
			$stmt->bindValue( 3, $pn );
			$stmt->bindValue( 4, $mail );
			$stmt->bindValue( 5, 'اکانت کاربر' );
			$stmt->execute();
			
			$signup = true;
		}
		$db = null;
        $db2 = null;
	}
?>
	<meta charset="UTF-8">
	<style>
		body {
			direction: rtl;
			font: 12px tahoma;
		}
		
		input {
			border: 1px solid #008;
		}
		
		form {
			padding: 2em;
			margin: 2em;
			background-color: #eee;
		}
	</style>
	<?php if( $signup == false ) : ?>
		
		<?php
			// نمایش پیام‌های خطا در صورت وجود
			foreach( $errors as $error ) {
				echo "<p>{$error}</p>";
			}
		?>
		
		<!-- نمایش فرم ثبت نام -->
		<form method="POST">
			<input type="text" name="username"placeholder="iD"><br>
			<input type="tel" name="pn"placeholder="PHONE NUMBER"><br>
			<input type="email" name="mail"placeholder="GMAiL"><br>
            <input type="password" name="password"placeholder="PASSWORD"><br>
		    <input type="submit" value="ثبت نام"style="background:#00A000;color:#FFFFFF;"><br>
		    <input type="reset">
		</form>
	<?php else: ?>
		<!-- نمایش پیام ورود به سایت -->
		اطلاعات بدون مشکل ثبت شد
		<hr>
		<a href="signin.php">ورود به سایت</a>
	<?php endif; ?>
</body>
</html>