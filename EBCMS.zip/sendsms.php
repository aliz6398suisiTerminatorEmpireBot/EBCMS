<?php
    include "db.php";
    $s = mysqli_real_escape_string($db2,$_POST["s"]);
    $g = mysqli_real_escape_string($db2,$_POST["g"]);
    $t = mysqli_real_escape_string($db2,$_POST["t"]);
    $stmt = $db->prepare( "INSERT INTO sms ( sender,geter,text ) VALUES ( ?, ?, ? )" );
	$stmt->bindValue( 1, $s );
	$stmt->bindValue( 2, $g );
	$stmt->bindValue( 3, $t );
	$stmt->execute();
	$db = null;
	$db2 = null;
?>